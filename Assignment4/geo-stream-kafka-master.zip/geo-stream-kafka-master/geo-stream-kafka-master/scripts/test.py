import requests
import time
import json
import geojson

with open("route1.json", "r") as r:
    route = geojson.load(r)
        
msg = {"name": "Entity_ONE"}

                
for lon, lat in route["features"][0]["geometry"]["coordinates"]:
    msg["lat"] = lat
    msg["lon"] = lon
    requests.post("http://127.0.0.1:8000/producer/geostream", json=msg)
    time.sleep(0.2)